"""
VBrowes — DB Fix Script
Run this ONCE if you see: "table orders has no column named order_ref"

Usage:
    python fix_db.py
"""
import sqlite3, os, shutil
from datetime import datetime

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vbrowes.db")

def fix():
    if not os.path.exists(DB):
        print("[OK] No existing DB found — will be created fresh when you run app.py")
        return

    # Backup first
    backup = DB + ".backup_" + datetime.now().strftime("%Y%m%d_%H%M%S")
    shutil.copy(DB, backup)
    print(f"[OK] Backup saved: {backup}")

    conn = sqlite3.connect(DB)
    cur  = conn.cursor()

    # Check orders columns
    try:
        cols = [r[1] for r in cur.execute("PRAGMA table_info(orders)").fetchall()]
    except:
        cols = []

    print(f"[INFO] Current orders columns: {cols}")

    needs_fix = (not cols) or \
                ("order_ref" not in cols) or \
                ("cod_fee"   not in cols) or \
                ("cust_name" not in cols)

    if needs_fix:
        print("[FIX] Dropping old orders table and recreating with correct schema...")
        cur.execute("DROP TABLE IF EXISTS orders")
        conn.commit()
    else:
        print("[OK] orders table schema is already correct!")
        conn.close()
        return

    # Create fresh tables
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS orders (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            order_ref  TEXT NOT NULL,
            cust_name  TEXT,
            cust_email TEXT,
            cust_phone TEXT,
            address    TEXT,
            items      TEXT,
            subtotal   INTEGER DEFAULT 0,
            shipping   INTEGER DEFAULT 0,
            cod_fee    INTEGER DEFAULT 0,
            total      INTEGER DEFAULT 0,
            pay_method TEXT,
            pay_detail TEXT,
            status     TEXT DEFAULT 'confirmed',
            ts         TEXT
        );
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT, email TEXT, message TEXT, ts TEXT
        );
        CREATE TABLE IF NOT EXISTS subscribers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL, ts TEXT
        );
    """)
    conn.commit()

    # Verify
    new_cols = [r[1] for r in conn.execute("PRAGMA table_info(orders)").fetchall()]
    print(f"[OK] New orders columns: {new_cols}")
    conn.close()

    print("\n✅ DB fixed successfully!")
    print("   Now run:  python app.py\n")

if __name__ == "__main__":
    fix()
