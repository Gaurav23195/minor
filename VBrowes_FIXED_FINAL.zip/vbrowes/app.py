"""
VBrowes Fashion Store — FINAL WORKING
"""
from flask import Flask, render_template, request, jsonify
import sqlite3, os, json, uuid
from datetime import datetime

app = Flask(__name__)
app.secret_key = "vbrowes2024"
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vbrowes.db")

PRODUCTS = [
    {"id":1,  "name":"Premium Formal Shirt",  "desc":"Premium quality formal shirt",       "price":1299, "category":"men",   "tag":"bestseller", "img":"https://jimmyluxury.in/cdn/shop/articles/Top_10_Budget_Shirt_Brands_for_Men_That_Look_Premium_copy_ac5bad5f-ae88-4e53-b51c-c4c6e8670cd8.webp"},
    {"id":2,  "name":"Women Ethnic Dress",    "desc":"Elegant traditional wear",           "price":1099, "category":"women", "tag":"new",        "img":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQo6nEr74Aw2_q3mXC4s4xZMDYeok3f2V-ee2g9CDE4A&s"},
    {"id":3,  "name":"Casual Comfort Tee",    "desc":"Comfortable everyday wear",          "price":899,  "category":"men",   "tag":"sale",       "img":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMkKYkibf1FbrYGyLcppDckBkKVkiOjCcGZC_JFXIv5Q&s"},
    {"id":4,  "name":"Fashion Accessories",   "desc":"Complete style accessories kit",     "price":699,  "category":"acc",   "tag":"popular",    "img":"https://sylvi.in/cdn/shop/articles/Best_Men_s_Fashion_Accessories_Under_2000_1600x.webp"},
    {"id":5,  "name":"Premium Watch",         "desc":"Luxury timepiece collection",        "price":1499, "category":"acc",   "tag":"bestseller", "img":"https://cdn.shopify.com/s/files/1/0571/6223/6113/files/Rig_o_One_White_eb6f40ed-bb93-4527-be14-36ce8d27449a_1024x1024.webp"},
    {"id":6,  "name":"Trending Watch 2026",   "desc":"Latest fashion watch",               "price":1999, "category":"acc",   "tag":"new",        "img":"https://sylvi.in/cdn/shop/articles/Top-Watch-Trends-Among-India_s-Millennials_Gen-Z-in-2026.webp"},
    {"id":7,  "name":"Gift Combo Set",        "desc":"Perfect gifting package",            "price":999,  "category":"gift",  "tag":"popular",    "img":"https://bbdgifts.com/cdn/shop/files/IMG-20240724-WA0101-1.jpg"},
    {"id":8,  "name":"Men Modern Fashion",    "desc":"Contemporary outfit style",          "price":1299, "category":"men",   "tag":"new",        "img":"https://fabavenue.in/storage/1-embrace-modern-trends-to-elevate-your-classic-mens-wardrobe.jpg"},
    {"id":9,  "name":"Slim Fit Casual",       "desc":"Daily comfort wear",                 "price":899,  "category":"men",   "tag":"sale",       "img":"https://m.media-amazon.com/images/I/61HOXaizGcL._SY695_.jpg"},
    {"id":10, "name":"Black Slim Trousers",   "desc":"Stylish slim fit trousers",          "price":1199, "category":"men",   "tag":"popular",    "img":"https://assets-jiocdn.ajio.com/medias/sys_master/root1/20250826/kvnn/68ad9f743d468c61ab9bbc80/-473Wx593H-702161446-black-MODEL.jpg"},
    {"id":11, "name":"Printed Summer Shirt",  "desc":"Trendy casual printed wear",         "price":999,  "category":"men",   "tag":"sale",       "img":"https://m.media-amazon.com/images/I/71JSBVBueiL.jpg"},
    {"id":12, "name":"Women Fusion Wear",     "desc":"Modern fusion fashion outfit",       "price":1349, "category":"women", "tag":"bestseller", "img":"https://indian-retailer.s3.ap-south-1.amazonaws.com/s3fs-public/2024-06/Untitled%20design_1.jpg"},
]
PMAP = {p["id"]: p for p in PRODUCTS}

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = sqlite3.connect(DB)
    # ── FORCE FIX: always check orders columns and drop if wrong ──
    cur = conn.cursor()
    try:
        cols = [r[1] for r in cur.execute("PRAGMA table_info(orders)").fetchall()]
        needs_fix = (not cols) or ("order_ref" not in cols) or ("cod_fee" not in cols) or ("cust_name" not in cols)
    except:
        needs_fix = True

    if needs_fix:
        cur.execute("DROP TABLE IF EXISTS orders")
        conn.commit()
        print("[VBrowes] orders table recreated with correct schema")

    cur.executescript("""
        CREATE TABLE IF NOT EXISTS orders (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            order_ref  TEXT NOT NULL,
            cust_name  TEXT,
            cust_email TEXT,
            cust_phone TEXT,
            address    TEXT,
            items      TEXT,
            subtotal   INTEGER DEFAULT 0,
            shipping   INTEGER DEFAULT 0,
            cod_fee    INTEGER DEFAULT 0,
            total      INTEGER DEFAULT 0,
            pay_method TEXT,
            pay_detail TEXT,
            status     TEXT DEFAULT 'confirmed',
            ts         TEXT
        );
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT, email TEXT, message TEXT, ts TEXT
        );
        CREATE TABLE IF NOT EXISTS subscribers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL, ts TEXT
        );
    """)
    conn.commit()
    conn.close()

# ── Pages ──────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    featured = [p for p in PRODUCTS if p["tag"] in ("bestseller","new")][:4]
    return render_template("index.html", products=PRODUCTS, featured=featured)

@app.route("/shop")
def shop():
    cat = request.args.get("cat","all")
    tag = request.args.get("tag","")
    q   = request.args.get("q","").lower()
    fil = PRODUCTS[:]
    if cat != "all": fil = [p for p in fil if p["category"]==cat]
    if tag:          fil = [p for p in fil if p["tag"]==tag]
    if q:            fil = [p for p in fil if q in p["name"].lower() or q in p["desc"].lower()]
    return render_template("shop.html", products=fil, cat=cat, tag=tag, q=q)

@app.route("/product/<int:pid>")
def product_detail(pid):
    p = PMAP.get(pid)
    if not p: return "Not found", 404
    related = [x for x in PRODUCTS if x["category"]==p["category"] and x["id"]!=pid][:3]
    return render_template("product.html", product=p, related=related)

@app.route("/cart")
def cart():
    return render_template("cart.html", products_json=json.dumps(PRODUCTS))

@app.route("/checkout")
def checkout():
    return render_template("checkout.html", products_json=json.dumps(PRODUCTS))

@app.route("/contact")
def contact():
    return render_template("contact.html")

@app.route("/joinus")
def joinus():
    return render_template("joinus.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/terms")
def terms():
    return render_template("terms.html")

# ── API: Place Order ───────────────────────────────────────────────────────────
@app.route("/api/order", methods=["POST"])
def api_order():
    try:
        d = request.get_json(force=True, silent=True)
        if not d:
            return jsonify({"ok": False, "error": "No data received"}), 400

        name   = str(d.get("name","")).strip()
        email  = str(d.get("email","")).strip()
        phone  = str(d.get("phone","")).strip()
        addr   = str(d.get("address","")).strip()
        pay_m  = str(d.get("payment_method","upi")).strip()
        pay_d  = str(d.get("payment_detail","")).strip()

        if not name:
            return jsonify({"ok": False, "error": "Please enter your name"}), 400
        if not email or "@" not in email:
            return jsonify({"ok": False, "error": "Please enter a valid email"}), 400

        items_raw = d.get("items", [])
        if not items_raw and d.get("product_id") is not None:
            items_raw = [{"id": int(d["product_id"]), "qty": 1}]
        if not items_raw:
            return jsonify({"ok": False, "error": "Cart is empty"}), 400

        order_items, subtotal = [], 0
        for it in items_raw:
            try:
                pid = int(it.get("id", 0))
                qty = max(1, int(it.get("qty", 1)))
            except:
                continue
            p = PMAP.get(pid)
            if not p:
                return jsonify({"ok": False, "error": f"Product ID {pid} not found"}), 404
            order_items.append({"id": pid, "name": p["name"], "price": p["price"], "qty": qty})
            subtotal += p["price"] * qty

        if not order_items:
            return jsonify({"ok": False, "error": "No valid products in cart"}), 400

        shipping = 0 if subtotal >= 999 else 99
        cod_fee  = 29 if pay_m == "cod" else 0
        total    = subtotal + shipping + cod_fee
        ref      = "VB" + uuid.uuid4().hex[:8].upper()
        ts       = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        conn = get_db()
        conn.execute(
            """INSERT INTO orders
               (order_ref, cust_name, cust_email, cust_phone, address,
                items, subtotal, shipping, cod_fee, total, pay_method, pay_detail, ts)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (ref, name, email, phone, addr,
             json.dumps(order_items), subtotal, shipping, cod_fee, total,
             pay_m, pay_d, ts)
        )
        conn.commit()
        conn.close()

        return jsonify({
            "ok":         True,
            "order_ref":  ref,
            "total":      total,
            "subtotal":   subtotal,
            "shipping":   shipping,
            "cod_fee":    cod_fee,
            "items_count": sum(i["qty"] for i in order_items),
            "message":    f"Order #{ref} confirmed! Total ₹{total}. Thank you {name}!"
        })

    except Exception as e:
        return jsonify({"ok": False, "error": f"Server error: {str(e)}"}), 500


# ── API: Contact ───────────────────────────────────────────────────────────────
@app.route("/api/contact", methods=["POST"])
def api_contact():
    try:
        d     = request.get_json(force=True, silent=True) or {}
        name  = str(d.get("name","")).strip()
        email = str(d.get("email","")).strip()
        msg   = str(d.get("message","")).strip()
        if not name or not email:
            return jsonify({"ok": False, "error": "Name and email required"}), 400
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        conn = get_db()
        conn.execute("INSERT INTO contacts(name,email,message,ts) VALUES(?,?,?,?)",
                     (name, email, msg, ts))
        conn.commit(); conn.close()
        return jsonify({"ok": True, "message": f"Thanks {name}! We'll get back to you soon."})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


# ── API: Subscribe ─────────────────────────────────────────────────────────────
@app.route("/api/subscribe", methods=["POST"])
def api_subscribe():
    try:
        d     = request.get_json(force=True, silent=True) or {}
        email = str(d.get("email","")).strip()
        if not email or "@" not in email:
            return jsonify({"ok": False, "error": "Invalid email"}), 400
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        conn = get_db()
        try:
            conn.execute("INSERT INTO subscribers(email,ts) VALUES(?,?)", (email, ts))
            conn.commit()
            return jsonify({"ok": True, "message": "Subscribed! Welcome to VBrowes 🎉"})
        except sqlite3.IntegrityError:
            return jsonify({"ok": False, "error": "Already subscribed!"}), 409
        finally:
            conn.close()
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


# ── API: Products ──────────────────────────────────────────────────────────────
@app.route("/api/products")
def api_products():
    cat  = request.args.get("cat","all")
    data = PRODUCTS if cat == "all" else [p for p in PRODUCTS if p["category"] == cat]
    return jsonify(data)


@app.route("/api/stats")
def api_stats():
    conn = get_db()
    c   = conn.execute("SELECT COUNT(*) FROM contacts").fetchone()[0]
    s   = conn.execute("SELECT COUNT(*) FROM subscribers").fetchone()[0]
    o   = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    rev = conn.execute("SELECT COALESCE(SUM(total),0) FROM orders").fetchone()[0]
    conn.close()
    return jsonify({"contacts":c,"subscribers":s,"orders":o,"revenue":rev,"products":len(PRODUCTS)})


if __name__ == "__main__":
    init_db()
    print("\n" + "="*52)
    print("  👗  VBrowes Fashion Store — FINAL")
    print("  🌐  http://127.0.0.1:5000")
    print("="*52 + "\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
